"""Mockup of the RQ1 validation figure, Sparseloop-Fig-13 style (expected result).

Synthetic data only. x = operand density, y = DRAM weight traffic normalized to
dense, per architecture. Line = Sparseloop analytical (uniform density model);
markers with seed error bars = nocsim Bernoulli traces (Tier B, matches the
line within ~5%); triangles = real spike traces plotted at their measured
per-layer density (Tier C, sit systematically above the line: temporal/spatial
spike correlation breaks the independence assumption).
"""
import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

rng = np.random.default_rng(7)

densities = np.array([0.05, 0.1, 0.3, 0.5, 0.9])


def analytic(p):
    # toy skipping model: traffic grows sublinearly with density
    return p ** 0.8


fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.8), sharey=True)

for ax, arch, c_err in zip(axes, ["PTB", "LoAS"], [0.10, 0.16]):
    p = np.linspace(0.02, 1.0, 100)
    ax.plot(p, analytic(p), color="0.25", lw=1.2, zorder=2,
            label="Sparseloop (uniform density)")

    # Tier B: Bernoulli, 3 seeds -> mean +- range, within ~5% of the line
    sim = analytic(densities) * (1 + rng.normal(0, 0.02, densities.size))
    err = analytic(densities) * 0.03
    ax.errorbar(densities, sim, yerr=err, fmt="s", ms=5, color="#4477aa",
                capsize=2.5, lw=1, zorder=4, label="nocsim, Bernoulli (3 seeds)")

    # Tier C: real traces, one point per layer at its measured density,
    # systematically above the analytical line
    dl = rng.uniform(0.1, 0.45, 10)
    real = analytic(dl) * (1 + c_err + rng.normal(0, 0.04, dl.size))
    ax.scatter(dl, real, s=26, marker="^", facecolor="#ee6677",
               edgecolor="white", lw=0.4, zorder=5,
               label="nocsim, real traces (per layer)")

    mae_b = np.mean(np.abs(sim / analytic(densities) - 1)) * 100
    mae_c = np.mean(np.abs(real / analytic(dl) - 1)) * 100
    ax.text(0.03, 0.96, f"{arch}\nBernoulli MAE {mae_b:.1f}%\nreal-trace gap {mae_c:.1f}%",
            transform=ax.transAxes, va="top", fontsize=7.5)

    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1.25)
    ax.set_xlabel("operand density")
    ax.tick_params(labelsize=8)

axes[0].set_ylabel("DRAM weight traffic\n(normalized to dense)")
axes[1].legend(fontsize=7, loc="lower right", framealpha=0.9)
fig.suptitle("Simulator validation (mock data, expected result)", fontsize=10)
fig.tight_layout(rect=(0, 0, 1, 0.94))
fig.savefig("validation_mock.png", dpi=200)
fig.savefig("validation_mock.pdf")
print("wrote validation_mock.{png,pdf}")
